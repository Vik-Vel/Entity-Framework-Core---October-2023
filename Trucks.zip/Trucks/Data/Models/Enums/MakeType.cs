﻿namespace Trucks.Data.Models.Enums
{
    public enum MakeType
    {
        Daf = 0,
        Man = 1,
        Mercedes = 2,
        Scania = 3,
        Volvo = 4,
    }
}
